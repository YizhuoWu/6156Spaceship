"""
Expose version
"""

__version__ = "2.0.9"
VERSION = __version__.split(".")
